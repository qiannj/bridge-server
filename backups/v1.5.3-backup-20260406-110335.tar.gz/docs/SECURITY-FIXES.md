# Bridge Server 安全修复指南

**对应审计**: [SECURITY-AUDIT.md](../SECURITY-AUDIT.md)  
**优先级**: P0 > P1 > P2 > P3

---

## P0-1: 修复认证绕过漏洞

### 问题代码

`app/auth.py` line 32-34:

```python
# ❌ 错误：默认允许
if not auth_tokens:
    return True
```

### 修复代码

```python
# ✅ 正确：默认拒绝
def verify_token(authorization: Optional[str] = Header(None)) -> bool:
    """验证 API Token"""
    if not authorization:
        raise HTTPException(status_code=401, detail="缺少认证信息")
    
    # 提取 Token
    if authorization.startswith("Bearer "):
        token = authorization[7:]
    else:
        token = authorization
    
    # 加载配置
    config = load_config()
    
    # 获取配置的 Tokens
    auth_tokens = config.get('server', {}).get('auth_tokens', [])
    
    # 🔒 修复：如果没有配置 Tokens，拒绝所有请求
    if not auth_tokens:
        logger.critical("未配置 auth_tokens，拒绝所有请求 - 请在 config.yaml 中配置")
        raise HTTPException(
            status_code=503, 
            detail="服务未配置认证，请联系管理员"
        )
    
    # 验证 Token
    if token in auth_tokens:
        return True
    
    # 记录失败的认证尝试
    logger.warning(f"认证失败：token={token[:8]}...")
    raise HTTPException(status_code=401, detail="无效的 Token")
```

### 测试

```bash
# 1. 不配置 auth_tokens 启动服务
# 2. 发送请求，应该返回 503
curl -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer test" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "hi"}]}'

# 预期响应：HTTP 503 Service Unavailable
```

---

## P0-2: API Key 加密存储与日志脱敏

### 问题 1: 明文存储

**修复**: 使用环境变量

```bash
# ~/.bridge-server/.env
DASHSCOPE_API_KEY=sk-xxx
MOONSHOT_API_KEY=sk-xxx
```

```python
# config.yaml
providers:
  dashscope:
    enabled: true
    base_url: https://dashscope.aliyuncs.com/compatible-mode/v1
    # ✅ 从环境变量读取
    api_key_env: DASHSCOPE_API_KEY
```

```python
# app/router.py
import os
from dotenv import load_dotenv

load_dotenv(Path.home() / '.bridge-server' / '.env')

def get_api_key(provider_config: dict) -> str:
    """获取 API Key（支持环境变量）"""
    if 'api_key_env' in provider_config:
        env_var = provider_config['api_key_env']
        api_key = os.getenv(env_var)
        if not api_key:
            raise ValueError(f"环境变量 {env_var} 未设置")
        return api_key
    elif 'api_key' in provider_config:
        return provider_config['api_key']
    else:
        raise ValueError("缺少 API Key 配置")
```

### 问题 2: 日志脱敏

```python
# ✅ 修复：日志脱敏函数
def mask_sensitive(value: str, visible_chars: int = 8) -> str:
    """脱敏敏感信息"""
    if not value or len(value) <= visible_chars:
        return "***"
    return value[:visible_chars] + "***"

# 使用示例
logger.info(f"调用 LLM | provider={provider} | key={mask_sensitive(api_key)}")
```

### 问题 3: 文件权限

```bash
# install.sh 中添加
chmod 600 ~/.bridge-server/config.yaml
chmod 600 ~/.bridge-server/.env
chown -R $USER:$USER ~/.bridge-server/
```

---

## P0-3: 实现速率限制

### 安装依赖

```bash
pip install slowapi
```

### 代码实现

```python
# app/main.py
from fastapi import FastAPI, Request
from slowapi import Limiter, _rate_limit_exceeded_handler
from slowapi.util import get_remote_address
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

# 初始化限流器
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=["100/minute", "1000/hour"]
)

app = FastAPI()
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# 应用限流
@app.post("/v1/chat/completions")
@limiter.limit("60/minute")  # 每分钟 60 次
async def chat_completions(request: Request, ...):
    ...
```

### 配置文件

```yaml
# config.yaml
rate_limiting:
  enabled: true
  default:
    per_minute: 100
    per_hour: 1000
  endpoints:
    /v1/chat/completions: 60/minute
    /v1/completions: 60/minute
    /health: 10/minute
```

---

## P1-1: 限制 CORS 配置

```python
# ❌ 错误：允许所有来源
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ 正确：限制特定来源
ALLOWED_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:8080",
    "https://your-domain.com",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["POST", "GET", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
    expose_headers=["X-Request-ID"],
    max_age=600,
)
```

---

## P1-2: 完善输入验证

```python
# app/main.py

# 常量定义
MAX_MESSAGES = 50
MAX_MESSAGE_LENGTH = 10000
MAX_TOTAL_LENGTH = 50000

@app.post("/v1/chat/completions")
@limiter.limit("60/minute")
async def chat_completions(request: Request, ...):
    try:
        # ✅ 验证 messages 字段
        if 'messages' not in request:
            raise HTTPException(400, "缺少 messages 字段")
        
        messages = request['messages']
        
        # ✅ 验证消息数量
        if not isinstance(messages, list):
            raise HTTPException(400, "messages 必须是数组")
        
        if len(messages) > MAX_MESSAGES:
            raise HTTPException(
                400, 
                f"消息数量超过限制 ({MAX_MESSAGES})"
            )
        
        if len(messages) == 0:
            raise HTTPException(400, "messages 不能为空")
        
        # ✅ 验证每条消息
        total_length = 0
        for i, msg in enumerate(messages):
            if not isinstance(msg, dict):
                raise HTTPException(400, f"消息 {i} 格式错误")
            
            content = msg.get('content', '')
            if not isinstance(content, str):
                raise HTTPException(400, f"消息 {i} 内容必须是字符串")
            
            if len(content) > MAX_MESSAGE_LENGTH:
                raise HTTPException(
                    400, 
                    f"消息 {i} 长度超过限制 ({MAX_MESSAGE_LENGTH})"
                )
            
            total_length += len(content)
        
        # ✅ 验证总长度
        if total_length > MAX_TOTAL_LENGTH:
            raise HTTPException(
                400, 
                f"消息总长度超过限制 ({MAX_TOTAL_LENGTH})"
            )
        
        # 获取最后一条消息
        last_message = messages[-1]
        text = last_message.get('content', '')
        
        if not text:
            raise HTTPException(400, "消息内容为空")
        
        # ... 继续处理
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"处理请求失败", exc_info=True)
        raise HTTPException(
            status_code=500, 
            detail="服务器内部错误，请稍后重试"
        )
```

---

## P1-3: 错误信息脱敏

```python
# ❌ 错误：泄露内部信息
raise HTTPException(status_code=500, detail=str(e))

# ✅ 正确：通用错误信息
SAFE_ERROR_MESSAGES = {
    "timeout": "请求超时，请稍后重试",
    "connection": "无法连接到服务，请稍后重试",
    "auth": "认证失败，请检查配置",
    "default": "服务器内部错误，请稍后重试"
}

def get_safe_error_message(e: Exception) -> str:
    """获取安全的错误信息"""
    error_str = str(e).lower()
    
    # 检查错误类型
    if "timeout" in error_str:
        return SAFE_ERROR_MESSAGES["timeout"]
    elif "connection" in error_str or "connect" in error_str:
        return SAFE_ERROR_MESSAGES["connection"]
    elif "auth" in error_str or "token" in error_str:
        return SAFE_ERROR_MESSAGES["auth"]
    else:
        return SAFE_ERROR_MESSAGES["default"]

# 使用
except Exception as e:
    logger.error(f"处理请求失败：{type(e).__name__}", exc_info=True)
    raise HTTPException(
        status_code=500, 
        detail=get_safe_error_message(e)
    )
```

---

## P2-1: 安装脚本完整性验证

```bash
#!/bin/bash
# install.sh

# 添加脚本哈希验证
SCRIPT_HASH="sha256:$(sha256sum "$0" | cut -d' ' -f1)"
EXPECTED_HASH="abc123..."  # 从安全渠道获取

if [ "$SCRIPT_HASH" != "$EXPECTED_HASH" ]; then
    echo "❌ 脚本完整性验证失败！"
    echo "预期：$EXPECTED_HASH"
    echo "实际：$SCRIPT_HASH"
    exit 1
fi

# 验证下载文件
verify_download() {
    local file=$1
    local expected_hash=$2
    
    actual_hash=$(sha256sum "$file" | cut -d' ' -f1)
    
    if [ "$actual_hash" != "$expected_hash" ]; then
        echo "❌ 下载文件验证失败！"
        rm -f "$file"
        exit 1
    fi
    
    echo "✅ 文件完整性验证通过"
}

# 使用示例
curl -L https://github.com/xxx/bridge-server/archive/main.zip -o /tmp/bs.zip
verify_download /tmp/bs.zip "expected_hash_here"
```

---

## P2-2: 配置向导隐藏输入

```python
# setup-wizard.py

import getpass  # 添加导入

def configure_dashscope() -> Optional[Dict]:
    """配置阿里云百炼"""
    print(f"\n→ 阿里云百炼 (DashScope)")
    print("  支持模型：qwen3.5-plus, qwen3.5-flash 等\n")
    
    # ✅ 修复：隐藏 API Key 输入
    api_key = getpass.getpass("  API Key: ")
    
    if not api_key:
        print_warning("跳过阿里云百炼配置")
        return None
    
    # ... 继续配置
```

---

## 📋 安全检查清单

### 部署前检查

```bash
#!/bin/bash
# security-check.sh

echo "=== Bridge Server 安全检查 ==="

# 1. 检查 auth_tokens 配置
if ! grep -q "auth_tokens:" ~/.bridge-server/config.yaml; then
    echo "❌ 未配置 auth_tokens"
    exit 1
fi
echo "✅ auth_tokens 已配置"

# 2. 检查文件权限
perms=$(stat -c %a ~/.bridge-server/config.yaml)
if [ "$perms" != "600" ]; then
    echo "❌ 配置文件权限不正确 (应为 600)"
    exit 1
fi
echo "✅ 配置文件权限正确"

# 3. 检查速率限制
if ! grep -q "rate_limiting:" ~/.bridge-server/config.yaml; then
    echo "⚠️  未配置速率限制（建议配置）"
fi

# 4. 检查 HTTPS
if grep -q "https:" ~/.bridge-server/config.yaml; then
    echo "✅ HTTPS 已配置"
else
    echo "⚠️  未配置 HTTPS（生产环境建议配置）"
fi

echo "=== 安全检查完成 ==="
```

---

## 🎯 修复验证

### 验证认证修复

```bash
# 1. 不配置 auth_tokens
echo "测试：未配置 auth_tokens"
curl -s -o /dev/null -w "%{http_code}" \
  -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer test" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "hi"}]}'
# 预期：503

# 2. 配置正确的 auth_tokens
echo "测试：配置正确的 auth_tokens"
curl -s -o /dev/null -w "%{http_code}" \
  -X POST http://localhost:8080/v1/chat/completions \
  -H "Authorization: Bearer correct-token" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "hi"}]}'
# 预期：200
```

### 验证速率限制

```bash
# 快速发送多个请求
for i in {1..70}; do
  curl -s -o /dev/null -w "%{http_code}\n" \
    -X POST http://localhost:8080/v1/chat/completions \
    -H "Authorization: Bearer test" \
    -H "Content-Type: application/json" \
    -d '{"messages": [{"role": "user", "content": "hi"}]}'
done

# 预期：前 60 个返回 200，之后返回 429
```

---

*修复指南版本：v1.0.0*  
*最后更新：2026-04-04*
