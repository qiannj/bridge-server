# Bridge Server 安全策略

**版本**: 2.0.0  
**生效日期**: 2026-04-05  
**最后审查**: 2026-04-05

---

## 🎯 安全目标

1. **零高危漏洞**: 生产环境不允许存在高危安全漏洞
2. **零密钥泄露**: 代码库中不允许出现硬编码的密钥
3. **防御深度**: 多层防护，单点失效不影响整体安全
4. **最小权限**: 默认拒绝，按需授权

---

## 🔒 安全控制措施

### 1. 认证安全

#### 要求

- ✅ 所有 API 端点（除健康检查）必须要求认证
- ✅ 支持 Bearer Token 和直接 Token 两种格式
- ✅ Token 验证使用常数时间比较（防止定时攻击）
- ✅ 未配置 auth_tokens 时拒绝所有请求

#### 实现

```python
# app/auth.py
def verify_token(authorization: Optional[str] = Header(None)):
    """验证认证 Token"""
    
    # 1. 检查认证头
    if not authorization:
        raise HTTPException(401, "缺少认证信息")
    
    # 2. 提取 Token（支持 Bearer 格式）
    token = authorization
    if token.startswith("Bearer "):
        token = token[7:]
    
    # 3. 加载配置
    config = load_config()
    auth_tokens = config.get('server', {}).get('auth_tokens', [])
    
    # 4. 检查是否配置
    if not auth_tokens:
        logger.critical("未配置 auth_tokens")
        raise HTTPException(503, "服务未配置认证")
    
    # 5. 常数时间比较（防止定时攻击）
    is_valid = False
    for valid_token in auth_tokens:
        if hmac.compare_digest(token, valid_token):
            is_valid = True
            break
    
    if not is_valid:
        raise HTTPException(401, "无效的 Token")
    
    return True
```

#### 测试

```python
# tests/security/test_authentication.py
def test_timing_attack_protection():
    """验证定时攻击防护"""
    # 测量有效和无效 Token 的验证时间差异
    # 差异应小于 10%
```

---

### 2. 速率限制

#### 要求

- ✅ 所有端点必须实施速率限制
- ✅ 默认限制：60 请求/分钟
- ✅ 健康检查端点：10 请求/分钟
- ✅ 超过限制返回 429 Too Many Requests

#### 实现

```python
# app/main.py
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.get("/health")
@limiter.limit("10/minute")
async def health_check(request: Request):
    ...

@app.post("/v1/chat/completions")
@limiter.limit("60/minute")
async def chat_completions(request: Request):
    ...
```

#### 配置

```yaml
# config.yaml
rate_limiting:
  enabled: true
  default:
    per_minute: 60
    per_hour: 1000
  endpoints:
    /v1/chat/completions: 60/minute
    /health: 10/minute
```

---

### 3. 输入验证

#### 要求

- ✅ 所有用户输入必须验证
- ✅ 最大消息长度：4096 字符
- ✅ 最大消息数量：50 条/请求
- ✅ 最大 token 数：32000
- ✅ 拒绝空消息列表

#### 实现

```python
# app/router.py
async def validate_request(request: ChatCompletionRequest):
    """验证请求"""
    
    # 1. 检查消息列表
    if not request.messages or len(request.messages) == 0:
        raise HTTPException(400, "消息列表不能为空")
    
    # 2. 检查消息数量
    if len(request.messages) > 50:
        raise HTTPException(400, "消息数量不能超过 50 条")
    
    # 3. 检查消息长度
    for msg in request.messages:
        if len(msg.content) > 4096:
            raise HTTPException(400, "单条消息不能超过 4096 字符")
    
    # 4. 检查 max_tokens
    if request.max_tokens and request.max_tokens > 32000:
        raise HTTPException(400, "max_tokens 不能超过 32000")
    
    return True
```

---

### 4. 密钥管理

#### 要求

- ✅ 禁止硬编码密钥
- ✅ 使用环境变量存储 API Key
- ✅ .env 文件必须添加到 .gitignore
- ✅ 定期轮换密钥（建议 90 天）

#### 实现

```yaml
# config.yaml - ✅ 正确
providers:
  dashscope:
    api_key_env: DASHSCOPE_API_KEY

# config.yaml - ❌ 错误
providers:
  dashscope:
    api_key: sk-xxx  # 禁止硬编码
```

```python
# app/router.py
import os

def get_api_key(provider_config: dict) -> str:
    """获取 API Key"""
    
    # 优先使用环境变量
    if 'api_key_env' in provider_config:
        env_var = provider_config['api_key_env']
        api_key = os.getenv(env_var)
        
        if not api_key:
            raise HTTPException(
                503,
                f"环境变量 {env_var} 未设置"
            )
        
        return api_key
    
    # 回退到直接配置（不推荐，仅用于测试）
    if 'api_key' in provider_config:
        logger.warning("使用直接配置的 API Key（不推荐）")
        return provider_config['api_key']
    
    raise HTTPException(503, "未配置 API Key")
```

#### .gitignore

```gitignore
# 密钥文件
.env
.env.local
.env.*.local

# 配置文件（包含敏感信息）
config.yaml
*.pem
*.key

# 日志（可能包含敏感信息）
logs/*.log
*.log
```

---

### 5. 日志安全

#### 要求

- ✅ 禁止记录完整 Token
- ✅ 禁止记录 API Key
- ✅ 敏感信息必须脱敏
- ✅ 日志文件权限：600

#### 实现

```python
# app/logger.py
import logging
import re

class SensitiveFilter(logging.Filter):
    """敏感信息过滤器"""
    
    def filter(self, record):
        # 脱敏 Token
        if hasattr(record, 'msg'):
            record.msg = re.sub(
                r'Bearer [a-zA-Z0-9_-]{10,}',
                'Bearer ***',
                str(record.msg)
            )
            record.msg = re.sub(
                r'sk-[a-zA-Z0-9]{20,}',
                'sk-***',
                str(record.msg)
            )
        return True

# 配置日志
logger = logging.getLogger('bridge-server')
logger.addFilter(SensitiveFilter())
```

#### 日志配置

```yaml
# config.yaml
logging:
  level: INFO
  file: /var/log/bridge-server/bridge-server.log
  max_size: 10MB
  backup_count: 5
  permissions: 0600  # 仅所有者可读写
```

---

### 6. 依赖安全

#### 要求

- ✅ 所有依赖必须来自官方源
- ✅ 禁止使用有已知高危漏洞的依赖
- ✅ 定期更新依赖（建议每周）
- ✅ 锁定依赖版本

#### 实现

```bash
# scripts/safety-check.sh
#!/bin/bash

# 扫描依赖漏洞
safety check -r requirements.txt --full-report

# 检查是否有高危漏洞
if safety check -r requirements.txt | grep -q "HIGH"; then
    echo "❌ 发现高危漏洞"
    exit 1
fi
```

#### requirements.txt

```txt
# 锁定版本
fastapi==0.109.0
uvicorn==0.27.0
pyyaml==6.0.1
httpx==0.26.0
slowapi==0.1.9

# 开发依赖
pytest==8.0.0
bandit==1.7.7
safety==3.0.0
```

---

## 🛡️ 安全测试

### 测试覆盖

| 测试类型 | 频率 | 工具 | 通过标准 |
|---------|------|------|---------|
| 单元测试 | 每次提交 | pytest | 100% 通过 |
| 安全扫描 | 每次提交 | bandit | 0 高危 |
| 密钥扫描 | 每次提交 | truffleHog | 0 泄露 |
| 依赖扫描 | 每天 | safety | 0 高危 |
| 渗透测试 | 每季度 | 人工 | 无严重问题 |

### 安全测试用例

#### 1. 暴力破解防护

```python
def test_brute_force_protection():
    """测试暴力破解防护"""
    # 连续发送 20 次错误 token
    # 应该触发速率限制（429）
```

#### 2. 注入攻击防护

```python
def test_prompt_injection():
    """测试提示词注入"""
    # 发送注入攻击 payload
    # 不应该泄露系统信息
```

#### 3. DoS 防护

```python
def test_dos_protection():
    """测试 DoS 防护"""
    # 发送超大 payload
    # 应该拒绝（413）
```

---

## 🚨 事件响应

### 密钥泄露

**发现密钥泄露后的响应流程**:

1. **立即轮换**: 立即更换泄露的密钥
2. **调查范围**: 确定泄露时间和范围
3. **修复漏洞**: 修复导致泄露的代码问题
4. **审查日志**: 检查是否有未授权访问
5. **文档记录**: 记录事件和响应过程

### 安全漏洞

**发现安全漏洞后的响应流程**:

1. **评估严重性**: 使用 CVSS 评分
2. **临时缓解**: 实施临时防护措施
3. **修复漏洞**: 开发并测试修复方案
4. **部署修复**: 紧急部署到生产环境
5. **事后审查**: 分析原因，防止再次发生

---

## 📋 安全检查清单

### 发布前检查

- [ ] 所有单元测试通过
- [ ] 所有集成测试通过
- [ ] Bandit 扫描无高危问题
- [ ] Safety 扫描无高危漏洞
- [ ] Secret 扫描无密钥泄露
- [ ] 代码审查完成
- [ ] 文档已更新

### 定期检查（每月）

- [ ] 审查和更新依赖
- [ ] 检查安全日志
- [ ] 审查访问日志
- [ ] 更新安全策略
- [ ] 进行渗透测试

### 年度检查

- [ ] 全面安全审计
- [ ] 密钥轮换
- [ ] 证书更新
- [ ] 灾难恢复演练
- [ ] 安全培训

---

## 📚 参考资源

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [FastAPI 安全指南](https://fastapi.tiangolo.com/tutorial/security/)
- [Python 安全最佳实践](https://docs.python.org/3/library/security.html)
- [CVSS 评分计算器](https://www.first.org/cvss/calculator/3.1)

---

*最后更新：2026-04-05*  
*下次审查：2026-07-05*
