#!/usr/bin/env python3
"""认证模块"""

import logging
from fastapi import HTTPException, Header
from typing import Optional
import yaml
from pathlib import Path

logger = logging.getLogger(__name__)


def load_config() -> dict:
    """加载配置文件"""
    config_file = Path.home() / ".bridge-server" / "config.yaml"
    if not config_file.exists():
        return {}

    with open(config_file, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def verify_token(authorization: Optional[str] = Header(None)) -> bool:
    """
    验证 API Token

    支持两种认证方式：
    1. Bearer Token: Authorization: Bearer <token>
    2. 直接 Token: Authorization: <token>
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="缺少认证信息")

    # 提取 Token
    if authorization.startswith("Bearer "):
        token = authorization[7:]
    else:
        token = authorization

    # 加载配置
    config = load_config()

    # 获取配置的 Tokens
    auth_tokens = config.get("server", {}).get("auth_tokens", [])

    # 🔒 安全修复：如果没有配置 Tokens，拒绝所有请求
    if not auth_tokens:
        logger.critical("未配置 auth_tokens，拒绝所有请求 - 请在 config.yaml 中配置")
        raise HTTPException(
            status_code=503, detail="服务未配置认证，请联系管理员配置 auth_tokens"
        )

    # 验证 Token
    if token in auth_tokens:
        return True

    # 记录失败的认证尝试
    logger.warning(f"认证失败：token={token[:8] if len(token) > 8 else '***'}...")
    raise HTTPException(status_code=401, detail="无效的 Token")
