#!/usr/bin/env python3
"""模型路由核心"""

import re
import httpx
import logging
from typing import Tuple, Dict, List

logger = logging.getLogger(__name__)

# 任务类型识别关键词
TASK_KEYWORDS = {
    "complex": ["推理", "证明", "推导", "复杂", "深入分析", "数学", "逻辑"],
    "coding": [
        "code",
        "python",
        "javascript",
        "函数",
        "编程",
        "写代码",
        "debug",
        "bug",
        "算法",
    ],
    "writing": ["写", "文章", "邮件", "报告", "文档", "文案", "润色", "改写"],
    "analysis": ["分析", "总结", "数据", "解释", "为什么", "如何", "对比", "评估"],
    "creative": ["创意", "故事", "头脑风暴", "想象", "设计", "诗歌", "小说"],
    "simple": ["你好", "hi", "hello", "谢谢", "再见", "在吗", "早上好", "晚上好"],
}


def detect_task_type(message: str) -> str:
    """
    根据消息内容识别任务类型

    Args:
        message: 用户消息

    Returns:
        任务类型：simple, coding, writing, analysis, creative, complex, general
    """
    if not message:
        return "general"

    # 清理消息
    clean_message = re.sub(r"[^\w\s\u4e00-\u9fff]", "", message.lower())

    # 按优先级检查任务类型
    priority_order = ["complex", "coding", "writing", "analysis", "creative", "simple"]

    for task_type in priority_order:
        keywords = TASK_KEYWORDS.get(task_type, [])
        if any(kw in clean_message for kw in keywords):
            return task_type

    return "general"


def route_model(message: str, config: dict) -> Tuple[str, str, str]:
    """
    根据任务类型路由到合适的模型

    Args:
        message: 用户消息
        config: 配置字典

    Returns:
        (selected_model, task_type, reason)
    """
    task_type = detect_task_type(message)

    # 获取路由配置
    routing_config = config.get("routing", {})
    strategy = routing_config.get("strategy", "balanced")
    model_mapping = routing_config.get("model_mapping", {})

    # 根据策略选择模型
    if strategy == "custom" and model_mapping:
        # 自定义映射
        model_id = model_mapping.get(
            task_type, model_mapping.get("general", "qwen3.5-plus")
        )
        reason = f"自定义路由：{task_type}"
    else:
        # 使用默认策略
        default_mapping = get_default_mapping(strategy)
        model_id = default_mapping.get(task_type, "qwen3.5-plus")
        reason = f"策略：{strategy}, 任务类型：{task_type}"

    # 查找完整模型配置（包含 provider 信息）
    full_model_id = find_full_model_id(model_id, config)

    logger.info(
        f"路由决策 | 任务类型={task_type} | 模型={full_model_id} | 策略={strategy}"
    )

    return full_model_id, task_type, reason


def get_default_mapping(strategy: str) -> Dict[str, str]:
    """获取默认路由映射"""

    if strategy == "cost-first":
        return {
            "simple": "qwen3.5-flash",
            "coding": "qwen3.5-plus",
            "writing": "qwen3.5-flash",
            "analysis": "qwen3.5-flash",
            "creative": "qwen3.5-plus",
            "complex": "qwen3.5-plus",
            "general": "qwen3.5-flash",
        }
    elif strategy == "quality-first":
        return {
            "simple": "qwen3.5-plus",
            "coding": "qwen3-coder-plus",
            "writing": "qwen3.5-plus",
            "analysis": "qwen3-max",
            "creative": "kimi-k2.5",
            "complex": "qwen3-max",
            "general": "qwen3.5-plus",
        }
    else:  # balanced
        return {
            "simple": "qwen3.5-flash",
            "coding": "qwen3-coder-plus",
            "writing": "qwen3.5-plus",
            "analysis": "qwen3.5-plus",
            "creative": "kimi-k2.5",
            "complex": "qwen3-max",
            "general": "qwen3.5-plus",
        }


def find_full_model_id(model_name: str, config: dict) -> str:
    """
    查找模型的完整 ID（包含 provider 前缀）

    例如：qwen3.5-plus → dashscope/qwen3.5-plus
    """
    providers = config.get("providers", {})

    for provider_name, provider_config in providers.items():
        if not provider_config.get("enabled", False):
            continue

        models = provider_config.get("models", {})
        if model_name in models:
            return f"{provider_name}/{model_name}"

    # 如果没找到，返回原始名称（可能是完整 ID）
    return model_name


async def call_llm(
    model: str, messages: list, config: dict, timeout: int = 120
) -> dict:
    """
    调用 LLM API

    Args:
        model: 模型 ID (格式：provider/model_name)
        messages: 消息列表
        config: 配置字典
        timeout: 超时时间（秒）

    Returns:
        API 响应
    """
    import time
    import os
    from services.usage import get_tracker

    start_time = time.time()

    # 解析模型 ID
    if "/" in model:
        provider, model_name = model.split("/", 1)
    else:
        provider = "dashscope"  # 默认
        model_name = model

    # 获取 provider 配置
    providers = config.get("providers", {})
    provider_config = providers.get(provider, {})

    if not provider_config.get("enabled", False):
        raise ValueError(f"Provider '{provider}' 未启用")

    # 🔒 安全：支持从环境变量读取 API Key
    api_key = None
    if "api_key_env" in provider_config:
        env_var = provider_config["api_key_env"]
        api_key = os.getenv(env_var)
        if not api_key:
            raise ValueError(f"环境变量 {env_var} 未设置")
    else:
        api_key = provider_config.get("api_key", "")

    if not api_key:
        raise ValueError(f"Provider '{provider}' 缺少 API Key")

    base_url = provider_config.get("base_url", "")

    # 🔒 安全：日志脱敏
    masked_key = api_key[:8] + "***" if len(api_key) > 8 else "***"
    logger.info(
        f"调用 LLM | provider={provider} | model={model_name} | key={masked_key}"
    )

    # 构建请求
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    payload = {"model": model_name, "messages": messages}

    # 发送请求
    async with httpx.AsyncClient(timeout=timeout) as client:
        response = await client.post(
            f"{base_url}/chat/completions", json=payload, headers=headers
        )

        duration_ms = int((time.time() - start_time) * 1000)

        # 记录用量
        try:
            response_data = response.json()
            usage_info = response_data.get("usage", {})
            tokens_in = usage_info.get("prompt_tokens", 0)
            tokens_out = usage_info.get("completion_tokens", 0)
            total_tokens = tokens_in + tokens_out

            # 估算成本
            cost = get_tracker().get_cost_estimate(model_name, total_tokens)

            # 记录
            record_usage(model_name, provider, tokens_in, tokens_out, cost, duration_ms)

            logger.info(
                f"API 调用完成 | tokens={total_tokens} | cost=¥{cost:.4f} | duration={duration_ms}ms"
            )

            return response_data
        except Exception as e:
            logger.warning(f"记录用量失败：{e}")
            return response.json()
