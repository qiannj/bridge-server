#!/usr/bin/env python3
"""
用量统计服务
记录和分析 API 使用情况
"""

import json
import time
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import logging

logger = logging.getLogger(__name__)


class UsageTracker:
    """用量跟踪器"""

    def __init__(self, config_dir: Optional[Path] = None):
        self.config_dir = config_dir or Path.home() / ".bridge-server"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.usage_file = self.config_dir / "usage.json"
        self.budget_file = self.config_dir / "budget.json"

    def record(
        self,
        model: str,
        provider: str,
        tokens_in: int,
        tokens_out: int,
        cost: float,
        duration_ms: int,
        success: bool = True,
    ):
        """
        记录一次 API 调用

        Args:
            model: 模型名称
            provider: 提供商
            tokens_in: 输入 token 数
            tokens_out: 输出 token 数
            cost: 费用（元）
            duration_ms: 耗时（毫秒）
            success: 是否成功
        """
        usage = self._load_usage()
        today = datetime.now().strftime("%Y-%m-%d")

        # 初始化今日数据
        if today not in usage["days"]:
            usage["days"][today] = {
                "requests": 0,
                "requests_success": 0,
                "requests_failed": 0,
                "tokens_in": 0,
                "tokens_out": 0,
                "cost": 0.0,
                "models": {},
            }

        # 更新总计
        usage["days"][today]["requests"] += 1
        if success:
            usage["days"][today]["requests_success"] += 1
        else:
            usage["days"][today]["requests_failed"] += 1

        usage["days"][today]["tokens_in"] += tokens_in
        usage["days"][today]["tokens_out"] += tokens_out
        usage["days"][today]["cost"] += cost

        # 更新模型统计
        if model not in usage["days"][today]["models"]:
            usage["days"][today]["models"][model] = {
                "requests": 0,
                "tokens_in": 0,
                "tokens_out": 0,
                "cost": 0.0,
            }

        usage["days"][today]["models"][model]["requests"] += 1
        usage["days"][today]["models"][model]["tokens_in"] += tokens_in
        usage["days"][today]["models"][model]["tokens_out"] += tokens_out
        usage["days"][today]["models"][model]["cost"] += cost

        # 更新提供商统计
        if provider not in usage["days"][today]:
            usage["days"][today][provider] = {"requests": 0, "cost": 0.0}
        usage["days"][today][provider]["requests"] += 1
        usage["days"][today][provider]["cost"] += cost

        self._save_usage(usage)
        logger.info(
            f"记录用量 | model={model} | cost=¥{cost:.4f} | tokens={tokens_in + tokens_out}"
        )

    def get_usage(self, period: str = "today") -> Dict:
        """
        获取用量统计

        Args:
            period: today, week, month, all

        Returns:
            用量数据字典
        """
        usage = self._load_usage()
        days = usage.get("days", {})

        if period == "today":
            target_dates = [datetime.now().strftime("%Y-%m-%d")]
        elif period == "yesterday":
            target_dates = [(datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")]
        elif period == "week":
            target_dates = [
                (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                for i in range(7)
            ]
        elif period == "month":
            target_dates = [
                (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
                for i in range(30)
            ]
        else:
            target_dates = list(days.keys())

        # 汇总数据
        result = {
            "period": period,
            "total_requests": 0,
            "total_requests_success": 0,
            "total_requests_failed": 0,
            "total_tokens_in": 0,
            "total_tokens_out": 0,
            "total_cost": 0.0,
            "models": {},
            "providers": {},
            "daily_breakdown": [],
        }

        for date in sorted(target_dates, reverse=True):
            if date not in days:
                continue

            day_data = days[date]
            result["total_requests"] += day_data.get("requests", 0)
            result["total_requests_success"] += day_data.get("requests_success", 0)
            result["total_requests_failed"] += day_data.get("requests_failed", 0)
            result["total_tokens_in"] += day_data.get("tokens_in", 0)
            result["total_tokens_out"] += day_data.get("tokens_out", 0)
            result["total_cost"] += day_data.get("cost", 0.0)

            # 模型汇总
            for model, model_data in day_data.get("models", {}).items():
                if model not in result["models"]:
                    result["models"][model] = {"requests": 0, "cost": 0.0}
                result["models"][model]["requests"] += model_data.get("requests", 0)
                result["models"][model]["cost"] += model_data.get("cost", 0.0)

            # 提供商汇总
            for provider in ["dashscope", "moonshot", "openai", "minimax"]:
                if provider in day_data:
                    if provider not in result["providers"]:
                        result["providers"][provider] = {"requests": 0, "cost": 0.0}
                    result["providers"][provider]["requests"] += day_data[provider].get(
                        "requests", 0
                    )
                    result["providers"][provider]["cost"] += day_data[provider].get(
                        "cost", 0.0
                    )

            # 每日明细
            result["daily_breakdown"].append(
                {
                    "date": date,
                    "requests": day_data.get("requests", 0),
                    "cost": day_data.get("cost", 0.0),
                }
            )

        return result

    def check_budget(self, config: Dict) -> Dict:
        """
        检查预算状态

        Args:
            config: 预算配置

        Returns:
            预算状态字典
        """
        budget_config = config.get("budget", {})

        if not budget_config.get("enabled", False):
            return {"enabled": False}

        daily_limit = budget_config.get("daily_limit", 50)
        monthly_limit = budget_config.get("monthly_limit", 1000)

        # 获取今日和本月用量
        today_usage = self.get_usage("today")
        month_usage = self.get_usage("month")

        daily_remaining = daily_limit - today_usage["total_cost"]
        monthly_remaining = monthly_limit - month_usage["total_cost"]

        # 判断是否超出预算
        daily_exceeded = daily_remaining < 0
        monthly_exceeded = monthly_remaining < 0

        return {
            "enabled": True,
            "daily": {
                "limit": daily_limit,
                "used": today_usage["total_cost"],
                "remaining": daily_remaining,
                "exceeded": daily_exceeded,
            },
            "monthly": {
                "limit": monthly_limit,
                "used": month_usage["total_cost"],
                "remaining": monthly_remaining,
                "exceeded": monthly_exceeded,
            },
            "action": budget_config.get("over_budget_action", "alert"),
        }

    def get_cost_estimate(self, model: str, tokens: int) -> float:
        """
        估算成本

        Args:
            model: 模型名称
            tokens: token 数量

        Returns:
            估算成本（元）
        """
        # 模型价格表（元/千 tokens）
        price_table = {
            "qwen3.5-flash": 0.002,
            "qwen3.5-plus": 0.004,
            "qwen3-max": 0.02,
            "qwen3-coder-plus": 0.008,
            "kimi-chat": 0.012,
            "kimi-k2.5": 0.025,
            "gpt-3.5-turbo": 0.014,  # $0.002 ≈ ¥0.014
            "gpt-4-turbo": 0.07,  # $0.01 ≈ ¥0.07
            "gpt-4o": 0.105,  # $0.015 ≈ ¥0.105
            "MiniMax-M2.5": 0.005,
        }

        price_per_1k = price_table.get(model, 0.004)  # 默认 qwen3.5-plus 价格
        return (tokens / 1000) * price_per_1k

    def _load_usage(self) -> Dict:
        """加载用量数据"""
        if not self.usage_file.exists():
            return {"days": {}, "version": "1.0"}

        try:
            with open(self.usage_file, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"加载用量数据失败：{e}")
            return {"days": {}, "version": "1.0"}

    def _save_usage(self, usage: Dict):
        """保存用量数据"""
        with open(self.usage_file, "w", encoding="utf-8") as f:
            json.dump(usage, f, indent=2, ensure_ascii=False)

    def cleanup_old_data(self, days_to_keep: int = 90):
        """清理旧数据"""
        usage = self._load_usage()
        cutoff_date = (datetime.now() - timedelta(days=days_to_keep)).strftime(
            "%Y-%m-%d"
        )

        original_count = len(usage["days"])
        usage["days"] = {k: v for k, v in usage["days"].items() if k >= cutoff_date}
        removed_count = original_count - len(usage["days"])

        if removed_count > 0:
            self._save_usage(usage)
            logger.info(f"清理 {removed_count} 天的旧用量数据")

    def export_report(self, period: str = "month", format: str = "json") -> str:
        """
        导出用量报告

        Args:
            period: today, week, month
            format: json, csv

        Returns:
            报告内容
        """
        usage = self.get_usage(period)

        if format == "json":
            return json.dumps(usage, indent=2, ensure_ascii=False)
        elif format == "csv":
            lines = ["date,requests,cost"]
            for day in usage["daily_breakdown"]:
                lines.append(f"{day['date']},{day['requests']},{day['cost']:.2f}")
            return "\n".join(lines)
        else:
            raise ValueError(f"不支持的格式：{format}")


# 全局用量跟踪器实例
_tracker: Optional[UsageTracker] = None


def get_tracker() -> UsageTracker:
    """获取全局用量跟踪器"""
    global _tracker
    if _tracker is None:
        _tracker = UsageTracker()
    return _tracker


def record_usage(
    model: str,
    provider: str,
    tokens_in: int,
    tokens_out: int,
    cost: float,
    duration_ms: int,
    success: bool = True,
):
    """快捷记录用量"""
    get_tracker().record(
        model, provider, tokens_in, tokens_out, cost, duration_ms, success
    )
