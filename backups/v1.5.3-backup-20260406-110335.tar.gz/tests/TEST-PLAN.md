# Bridge Server v1.4.0 测试方案

**版本**: 1.0.0  
**创建日期**: 2026-04-04  
**目标**: 零严重 Bug，生产就绪

---

## 📋 测试策略

### 测试金字塔

```
        ╱╲
       ╱  ╲      E2E 测试 (10%)
      ╱────╲    
     ╱      ╲   集成测试 (30%)
    ╱────────╲  
   ╱          ╲ 单元测试 (60%)
  ╱────────────╲
```

### 测试类型

| 类型 | 比例 | 目标 | 工具 |
|------|------|------|------|
| **单元测试** | 60% | 函数/方法级别 | pytest |
| **集成测试** | 30% | 模块间交互 | pytest + httpx |
| **E2E 测试** | 10% | 完整用户流程 | pytest + Docker |
| **性能测试** | - | 响应时间/并发 | locust |
| **安全测试** | - | 漏洞扫描 | bandit, safety |

---

## 🔒 功能 1: SSL 证书支持 - 测试方案

### 测试环境

```bash
# Docker Compose 测试环境
docker-compose -f docker-compose.test.yml up -d

# 测试域名
# - localhost (自签名)
# - test.bridge.local (自定义证书)
```

### 测试用例

#### 1.1 Let's Encrypt 自动申请

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| SSL-001 | 正常申请 | `./deploy.sh enable-ssl --domain test.example.com` | 证书成功申请，HTTPS 可用 | P0 |
| SSL-002 | 域名验证失败 | 使用无效域名 | 错误提示清晰，回滚到 HTTP | P0 |
| SSL-003 | 速率限制 | 短时间内多次申请 | 提示 Let's Encrypt 速率限制 | P1 |
| SSL-004 | 自动续期 | 证书过期前 30 天 | 自动续期成功 | P1 |
| SSL-005 | 续期失败 | 模拟续期失败 | 保留旧证书，告警通知 | P1 |

**测试脚本**:
```bash
# tests/ssl/test_letsencrypt.py
def test_letsencrypt_success():
    """SSL-001: 正常申请"""
    result = run_command("./deploy.sh enable-ssl --domain test.example.com")
    assert result.returncode == 0
    assert "Certificate issued" in result.stdout
    assert https_request("https://test.example.com/health").status_code == 200

def test_invalid_domain():
    """SSL-002: 域名验证失败"""
    result = run_command("./deploy.sh enable-ssl --domain invalid.nonexistent")
    assert result.returncode != 0
    assert "Domain validation failed" in result.stderr
```

---

#### 1.2 自定义证书

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| SSL-101 | 有效证书 | 提供有效 PEM 证书 | HTTPS 正常启用 | P0 |
| SSL-102 | 证书过期 | 提供过期证书 | 错误提示，拒绝启动 | P0 |
| SSL-103 | 证书链不完整 | 缺少中间证书 | 警告但允许启动 | P2 |
| SSL-104 | 密钥不匹配 | 证书和私钥不匹配 | 错误提示，拒绝启动 | P0 |
| SSL-105 | 证书格式错误 | 提供非 PEM 格式 | 错误提示，格式转换建议 | P2 |

**测试脚本**:
```bash
# tests/ssl/test_custom_cert.py
def test_valid_certificate():
    """SSL-101: 有效证书"""
    copy_files("tests/fixtures/valid-cert.pem", "docker/ssl/certs/")
    result = run_command("./deploy.sh enable-ssl --custom")
    assert result.returncode == 0
    assert verify_ssl("https://localhost") is True

def test_expired_certificate():
    """SSL-102: 证书过期"""
    copy_files("tests/fixtures/expired-cert.pem", "docker/ssl/certs/")
    result = run_command("./deploy.sh enable-ssl --custom")
    assert result.returncode != 0
    assert "Certificate expired" in result.stderr
```

---

#### 1.3 自签名证书

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| SSL-201 | 生成成功 | `./deploy.sh enable-ssl --self-signed` | 证书生成，HTTPS 可用 | P0 |
| SSL-202 | 浏览器警告 | 访问 HTTPS 页面 | 浏览器提示"不安全"（预期） | P2 |
| SSL-203 | 自定义有效期 | `--days 30` | 证书有效期 30 天 | P2 |
| SSL-204 | 自定义 CN | `--cn myserver.local` | 证书 CN 字段匹配 | P2 |

---

#### 1.4 HTTPS 功能测试

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| SSL-301 | HTTP 重定向 | 访问 http:// | 自动重定向到 https:// | P1 |
| SSL-302 | TLS 版本 | 检查 TLS 版本 | 仅支持 TLS 1.2+ | P1 |
| SSL-303 | 加密套件 | 检查加密套件 | 仅强加密套件 | P1 |
| SSL-304 | HSTS | 检查响应头 | Strict-Transport-Security 存在 | P2 |
| SSL-305 | OCSP Stapling | 检查 OCSP | OCSP 响应正常 | P2 |

**测试脚本**:
```bash
# tests/ssl/test_https_functionality.py
def test_http_redirect():
    """SSL-301: HTTP 重定向"""
    response = http_request("http://localhost/health", allow_redirects=False)
    assert response.status_code == 301
    assert response.headers["Location"].startswith("https://")

def test_tls_version():
    """SSL-302: TLS 版本"""
    result = run_command("openssl s_client -connect localhost:443 -tls1_1")
    assert "handshake failure" in result.stderr  # TLS 1.1 应失败
    
    result = run_command("openssl s_client -connect localhost:443 -tls1_2")
    assert "handshake failure" not in result.stderr  # TLS 1.2 应成功
```

---

### 测试覆盖率要求

- [ ] 代码覆盖率 ≥ 90%
- [ ] 分支覆盖率 ≥ 85%
- [ ] 所有 P0 测试用例通过
- [ ] 无严重安全漏洞

---

## ⚖️ 功能 2: 多实例负载均衡 - 测试方案

### 测试环境

```bash
# 3 实例负载均衡
docker-compose -f docker-compose.lb.yml up -d --scale bridge-server=3

# 测试工具
ab -n 1000 -c 10 http://localhost/  # Apache Bench
wrk -t12 -c400 -d30s http://localhost/  # wrk
```

### 测试用例

#### 2.1 负载均衡算法

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| LB-001 | 轮询算法 | 发送 100 个请求 | 3 个实例各接收 ~33 个请求 | P0 |
| LB-002 | 最少连接 | 模拟实例 1 负载高 | 新请求路由到实例 2/3 | P1 |
| LB-003 | IP 哈希 | 同一 IP 多次请求 | 始终路由到同一实例 | P1 |
| LB-004 | 权重配置 | 实例 1 权重=2，实例 2 权重=1 | 实例 1 接收 2 倍请求 | P2 |

**测试脚本**:
```python
# tests/loadbalancing/test_algorithms.py
def test_round_robin():
    """LB-001: 轮询算法"""
    responses = [send_request() for _ in range(100)]
    instance_counts = count_instances(responses)
    assert all(30 <= count <= 40 for count in instance_counts.values())

def test_least_connections():
    """LB-002: 最少连接"""
    # 模拟实例 1 高负载
    simulate_load(instance=1, requests=500)
    
    # 新请求应路由到其他实例
    response = send_request()
    assert response.instance_id != 1
```

---

#### 2.2 健康检查

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| LB-101 | 实例故障检测 | 停止实例 1 | 10 秒内标记为 unhealthy | P0 |
| LB-102 | 故障转移 | 实例 1 故障后发送请求 | 请求路由到实例 2/3 | P0 |
| LB-103 | 自动恢复 | 重启实例 1 | 30 秒内恢复为 healthy | P1 |
| LB-104 | 健康检查间隔 | 修改 interval=5s | 每 5 秒检查一次 | P2 |
| LB-105 | 健康检查超时 | 模拟实例响应慢 | 标记为 unhealthy | P1 |

**测试脚本**:
```python
# tests/loadbalancing/test_health_check.py
def test_instance_failure_detection():
    """LB-101: 实例故障检测"""
    stop_instance("bridge-server-1")
    wait(10)  # 等待 10 秒
    status = get_instance_status("bridge-server-1")
    assert status == "unhealthy"

def test_failover():
    """LB-102: 故障转移"""
    stop_instance("bridge-server-1")
    
    for _ in range(100):
        response = send_request()
        assert response.instance_id != 1
```

---

#### 2.3 扩缩容

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| LB-201 | 水平扩展 | `./deploy.sh scale 5` | 5 个实例运行 | P0 |
| LB-202 | 缩容 | `./deploy.sh scale 2` | 2 个实例运行，连接不中断 | P0 |
| LB-203 | 滚动更新 | 更新镜像版本 | 零停机更新 | P1 |
| LB-204 | 自动扩缩容 | CPU > 80% 持续 1 分钟 | 自动增加实例 | P2 |

---

#### 2.4 性能测试

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| LB-301 | 单实例吞吐 | 1 实例，100 并发 | QPS ≥ 500 | P1 |
| LB-302 | 多实例吞吐 | 3 实例，100 并发 | QPS ≥ 1500 | P1 |
| LB-303 | 负载均衡开销 | 对比直连和 LB | 延迟增加 < 5ms | P1 |
| LB-304 | 长连接 | 1000 个 keep-alive 连接 | 连接稳定，无泄漏 | P2 |
| LB-305 | 压力测试 | 1000 并发，持续 5 分钟 | 无实例崩溃，错误率 < 0.1% | P1 |

**测试脚本**:
```bash
# tests/loadbalancing/test_performance.sh
# LB-301: 单实例吞吐
ab -n 10000 -c 100 http://instance-1:19377/health
# 预期：QPS ≥ 500

# LB-303: 负载均衡开销
# 直连
ab -n 1000 -c 10 http://instance-1:19377/health
# 通过 LB
ab -n 1000 -c 10 http://localhost/health
# 对比：延迟差 < 5ms
```

---

### 测试覆盖率要求

- [ ] 所有 P0 测试用例通过
- [ ] 故障转移时间 < 10 秒
- [ ] 负载均衡开销 < 5ms
- [ ] 错误率 < 0.1%（压力测试）

---

## 🔥 功能 3: 配置热重载 - 测试方案

### 测试环境

```bash
# 启动服务
bridge-server start

# 监控日志
tail -f /var/log/bridge-server/reload.log
```

### 测试用例

#### 3.1 文件监听自动重载

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| HR-001 | 修改 auth_tokens | 编辑 config.yaml，添加 token | 1 秒内重载，新 token 可用 | P0 |
| HR-002 | 修改 rate_limiting | 修改限流配置 | 1 秒内重载，新限制生效 | P0 |
| HR-003 | 修改 providers | 启用新提供商 | 1 秒内重载，新提供商可用 | P0 |
| HR-004 | 修改 budget | 修改预算限制 | 1 秒内重载，新预算生效 | P1 |
| HR-005 | 修改 port/host | 修改端口配置 | 提示需要重启，不重载 | P1 |

**测试脚本**:
```python
# tests/hotreload/test_file_watcher.py
def test_auth_tokens_reload():
    """HR-001: 修改 auth_tokens"""
    # 初始配置
    old_config = load_config()
    old_config["server"]["auth_tokens"] = ["old-token"]
    save_config(old_config)
    
    # 修改配置
    new_config = load_config()
    new_config["server"]["auth_tokens"] = ["new-token"]
    save_config(new_config)
    
    # 等待重载
    wait(2)
    
    # 验证新 token 可用
    response = send_request(headers={"Authorization": "Bearer new-token"})
    assert response.status_code == 200
    
    # 验证旧 token 失效
    response = send_request(headers={"Authorization": "Bearer old-token"})
    assert response.status_code == 401
```

---

#### 3.2 SIGHUP 信号触发

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| HR-101 | 发送 SIGHUP | `kill -HUP $(pidof bridge-server)` | 配置重载成功 | P0 |
| HR-102 | 连接保持 | 重载期间有活跃连接 | 连接不中断 | P1 |
| HR-103 | 配置错误处理 | 发送错误配置后 SIGHUP | 拒绝重载，使用旧配置 | P1 |

**测试脚本**:
```python
# tests/hotreload/test_sighup.py
def test_sighup_reload():
    """HR-101: 发送 SIGHUP"""
    pid = get_bridge_server_pid()
    run_command(f"kill -HUP {pid}")
    wait(2)
    assert "Configuration reloaded" in get_log()

def test_connection_keepalive():
    """HR-102: 连接保持"""
    # 发起长连接请求
    future = send_async_request(sleep=5)
    
    # 中途触发重载
    wait(1)
    pid = get_bridge_server_pid()
    run_command(f"kill -HUP {pid}")
    
    # 验证请求成功完成
    response = future.result()
    assert response.status_code == 200
```

---

#### 3.3 API 端点触发

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| HR-201 | 正常重载 | `POST /api/reload` | 返回 200，重载成功 | P0 |
| HR-202 | 认证保护 | 无 token 调用 | 返回 401 | P0 |
| HR-203 | 部分重载 | `POST /api/reload?section=providers` | 仅重载指定模块 | P2 |
| HR-204 | 重载状态 | `GET /api/reload/status` | 返回上次重载时间和结果 | P2 |

**测试脚本**:
```python
# tests/hotreload/test_api_endpoint.py
def test_reload_api():
    """HR-201: 正常重载"""
    response = post("/api/reload", headers={"Authorization": "Bearer admin-token"})
    assert response.status_code == 200
    assert response.json()["status"] == "success"

def test_reload_without_auth():
    """HR-202: 认证保护"""
    response = post("/api/reload")
    assert response.status_code == 401
```

---

#### 3.4 配置项验证

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| HR-301 | 支持热重载的配置 | 修改 auth_tokens/rate_limiting/providers | 重载成功 | P0 |
| HR-302 | 不支持热重载的配置 | 修改 port/host | 提示需要重启 | P1 |
| HR-303 | 配置语法错误 | 编辑为无效 YAML | 拒绝重载，错误提示 | P0 |
| HR-304 | 配置回滚 | 重载失败后 | 自动回滚到旧配置 | P1 |

---

### 测试覆盖率要求

- [ ] 所有 P0 测试用例通过
- [ ] 重载延迟 < 2 秒
- [ ] 重载期间连接不中断
- [ ] 配置错误时拒绝重载

---

## 📚 功能 4: Provider 配置库 - 测试方案

### 测试环境

```bash
# 测试所有提供商连通性
bridge-server test-providers --all

# 测试特定提供商
bridge-server test-providers --provider dashscope
```

### 测试用例

#### 4.1 提供商注册表加载

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| PR-001 | 加载注册表 | 启动服务 | 15 家提供商加载成功 | P0 |
| PR-002 | 提供商信息完整 | 检查每家提供商 | base_url/models/pricing 完整 | P0 |
| PR-003 | 自定义提供商 | 添加自定义提供商 | 加载成功，可正常使用 | P0 |
| PR-004 | 注册表更新 | 更新 registry.yaml | 热重载或重启后生效 | P1 |

**测试脚本**:
```python
# tests/providers/test_registry.py
def test_registry_load():
    """PR-001: 加载注册表"""
    providers = load_providers()
    assert len(providers) == 15  # 15 家全球提供商
    
def test_provider_info():
    """PR-002: 提供商信息完整"""
    for provider in load_providers():
        assert provider.base_url is not None
        assert len(provider.models) >= 1
        assert provider.models[0].pricing is not None
```

---

#### 4.2 交互式配置向导

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| PR-101 | 选择区域 | `bridge-server setup` | 显示区域选择菜单 | P0 |
| PR-102 | 选择提供商 | 选择"阿里云通义千问" | 显示该提供商所有模型 | P0 |
| PR-103 | 选择模型 | 选择"qwen3-max" | 显示模型详情和价格 | P0 |
| PR-104 | 输入 API Key | 输入 sk-xxx | 验证格式（可选） | P1 |
| PR-105 | 生成配置 | 完成选择 | 生成 config.yaml | P0 |
| PR-106 | 配置文件验证 | 检查生成的配置 | 语法正确，可加载 | P0 |

**测试脚本**:
```python
# tests/providers/test_setup_wizard.py
def test_region_selection():
    """PR-101: 选择区域"""
    wizard = SetupWizard()
    wizard.select_region("CN")
    providers = wizard.get_providers()
    assert len(providers) == 7  # 7 家中国提供商

def test_config_generation():
    """PR-105: 生成配置"""
    wizard = SetupWizard()
    wizard.select_provider("dashscope")
    wizard.select_model("qwen3-max")
    wizard.set_api_key("sk-test123")
    wizard.generate_config()
    
    config = load_config()
    assert config["providers"]["template"] == "dashscope"
    assert config["providers"]["selected_model"] == "qwen3-max"
```

---

#### 4.3 提供商连通性测试

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| PR-201 | 通义千问连通性 | 发送测试请求 | 返回成功 | P0 |
| PR-202 | Kimi 连通性 | 发送测试请求 | 返回成功 | P0 |
| PR-203 | OpenAI 连通性 | 发送测试请求 | 返回成功 | P0 |
| PR-204 | 无效 API Key | 使用错误 Key | 返回 401，错误提示清晰 | P0 |
| PR-205 | 网络超时 | 模拟网络故障 | 超时错误，建议检查网络 | P1 |
| PR-206 | 限流处理 | 触发提供商限流 | 返回 429，建议稍后重试 | P1 |

**测试脚本**:
```python
# tests/providers/test_connectivity.py
@pytest.mark.parametrize("provider", ["dashscope", "moonshot", "openai", "anthropic", "google"])
def test_provider_connectivity(provider):
    """PR-201~203: 提供商连通性"""
    result = test_provider(provider)
    assert result.success is True
    assert result.latency < 1000  # 延迟 < 1 秒

def test_invalid_api_key():
    """PR-204: 无效 API Key"""
    result = test_provider("dashscope", api_key="invalid")
    assert result.success is False
    assert result.status_code == 401
    assert "Invalid API key" in result.error_message
```

---

#### 4.4 模型信息验证

| ID | 测试项 | 步骤 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| PR-301 | 上下文长度 | 检查所有模型 | context_length > 0 | P1 |
| PR-302 | 价格信息 | 检查所有模型 | pricing 完整（input/output） | P1 |
| PR-303 | 能力标签 | 检查所有模型 | capabilities 非空 | P2 |
| PR-304 | 模型实际可用 | 发送请求到各模型 | 返回成功 | P1 |

---

### 测试覆盖率要求

- [ ] 所有 P0 测试用例通过
- [ ] 15 家提供商全部可加载
- [ ] 至少 5 家提供商连通性测试通过（需 API Key）
- [ ] 配置文件生成成功率 100%

---

## 📊 综合测试

### 集成测试场景

| ID | 场景 | 步骤 | 预期结果 | 优先级 |
|----|------|------|---------|--------|
| INT-001 | 新用户快速启动 | 运行 setup → 选择提供商 → 启动服务 | 5 分钟内完成配置并可用 | P0 |
| INT-002 | SSL + 负载均衡 | 启用 SSL → 部署 3 实例 → 测试 HTTPS | HTTPS 正常，负载均衡工作 | P1 |
| INT-003 | 热重载 + Provider | 修改 providers → 热重载 → 测试新配置 | 新提供商立即生效 | P1 |
| INT-004 | 完整生产环境 | SSL + LB + 热重载 + 多 Provider | 所有功能正常，性能达标 | P0 |

---

### 性能基准测试

| 指标 | 目标值 | 测试方法 | 优先级 |
|------|--------|---------|--------|
| **启动时间** | < 10s | `time bridge-server start` | P1 |
| **请求延迟** | < 50ms | 本地路由请求 | P0 |
| **热重载延迟** | < 2s | 修改配置到生效时间 | P0 |
| **并发支持** | ≥ 1000 QPS | ab -n 10000 -c 100 | P1 |
| **内存占用** | < 500MB | 空闲状态 | P2 |
| **SSL 握手** | < 100ms | openssl s_time | P2 |

---

### 安全测试

| ID | 测试项 | 工具 | 预期结果 | 优先级 |
|----|--------|------|---------|--------|
| SEC-001 | 代码扫描 | bandit | 无高危漏洞 | P0 |
| SEC-002 | 依赖扫描 | safety | 无已知漏洞 | P0 |
| SEC-003 | SSL 配置 | ssl-labs | A+ 评级 | P1 |
| SEC-004 | 渗透测试 | OWASP ZAP | 无高危漏洞 | P1 |
| SEC-005 | 认证绕过 | 手动测试 | 无法绕过 | P0 |
| SEC-006 | 注入攻击 | SQL/命令注入测试 | 无法注入 | P0 |

---

## ✅ 发布标准

### 必须满足（P0）

- [ ] 所有 P0 测试用例通过
- [ ] 无严重（Critical）Bug
- [ ] 代码覆盖率 ≥ 80%
- [ ] 安全扫描无高危漏洞
- [ ] 性能基准测试达标

### 建议满足（P1）

- [ ] 所有 P1 测试用例通过 ≥ 90%
- [ ] 代码覆盖率 ≥ 90%
- [ ] 文档完整
- [ ] 至少 1 个真实用户测试

### 可选满足（P2）

- [ ] 所有 P2 测试用例通过 ≥ 80%
- [ ] 代码覆盖率 ≥ 95%

---

## 📝 测试报告模板

```markdown
# Bridge Server v1.4.0 测试报告

**测试日期**: 2026-04-xx  
**测试人员**: xxx  
**测试环境**: Docker Compose, Ubuntu 22.04

## 测试结果

| 功能 | P0 通过 | P1 通过 | P2 通过 | 状态 |
|------|--------|--------|--------|------|
| SSL 证书 | 15/15 | 10/12 | 5/8 | ✅ |
| 负载均衡 | 12/12 | 8/10 | 4/6 | ✅ |
| 热重载 | 10/10 | 6/8 | 3/4 | ✅ |
| Provider 库 | 20/20 | 15/18 | 10/12 | ✅ |

## Bug 统计

| 严重程度 | 数量 | 已修复 | 待修复 |
|---------|------|--------|--------|
| Critical | 0 | 0 | 0 |
| High | 2 | 2 | 0 |
| Medium | 5 | 4 | 1 |
| Low | 10 | 8 | 2 |

## 性能指标

| 指标 | 目标值 | 实测值 | 状态 |
|------|--------|--------|------|
| 启动时间 | < 10s | 8.5s | ✅ |
| 请求延迟 | < 50ms | 35ms | ✅ |
| 热重载延迟 | < 2s | 1.2s | ✅ |
| 并发支持 | ≥ 1000 QPS | 1250 QPS | ✅ |

## 发布建议

✅ 建议发布 v1.4.0

**理由**:
- 所有 P0 测试通过
- 无 Critical/High Bug
- 性能指标全部达标
```

---

*创建日期：2026-04-04*  
*版本：v1.4.0*  
*状态：📋 待执行*
