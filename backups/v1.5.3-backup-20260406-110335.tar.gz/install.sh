#!/bin/bash
# Bridge Server 一键安装脚本（跨平台 - 无需 root 权限）
# 使用方式：curl -fsSL https://example.com/install.sh | bash

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日志函数
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# ============================================
# 配置路径（全部使用用户目录，无需 sudo）
# ============================================
INSTALL_DIR="${INSTALL_DIR:-$HOME/.local/opt/bridge-server}"
CONFIG_DIR="${CONFIG_DIR:-$HOME/.bridge-server}"
LOG_DIR="${LOG_DIR:-$HOME/.local/var/log/bridge-server}"
BIN_DIR="${BIN_DIR:-$HOME/.local/bin}"

# 检测运行环境
detect_environment() {
    if [ -f /.dockerenv ]; then
        ENVIRONMENT="docker"
    elif command -v systemctl &> /dev/null && [ -d /etc/systemd/system ]; then
        ENVIRONMENT="linux-systemd"
    elif command -v launchctl &> /dev/null; then
        ENVIRONMENT="macos-launchd"
    else
        ENVIRONMENT="standalone"
    fi
    
    log_info "运行环境：$ENVIRONMENT"
}

# ============================================
# 依赖检查（Python、venv、pip）
# ============================================

# 检查 Python 和 venv
check_python_venv() {
    log_info "检查 Python 环境..."
    
    # 检查 Python
    if ! command -v python3 &> /dev/null; then
        log_error "Python 3 未安装"
        show_python_install_guide
        exit 1
    fi
    
    # 检查 Python 版本
    PYTHON_VERSION=$(python3 --version | cut -d' ' -f2)
    if ! version_check "$PYTHON_VERSION" "3.8"; then
        log_error "Python 版本过低：$PYTHON_VERSION (需要 3.8+)"
        show_python_install_guide
        exit 1
    fi
    
    log_success "Python $PYTHON_VERSION 已安装"
    
    # 检查 venv 模块
    if ! python3 -c "import venv" 2>/dev/null; then
        log_error "python3-venv 模块未安装"
        echo ""
        echo "请安装 python3-venv:"
        echo "  Ubuntu/Debian: sudo apt install python3-venv"
        echo "  macOS: brew install python3"
        echo "  CentOS: sudo yum install python3-venv"
        exit 1
    fi
    
    log_success "python3-venv 模块可用"
}

# 检查 pip
check_pip() {
    log_info "检查 pip..."
    
    # 优先检查 pip3
    if command -v pip3 &> /dev/null; then
        log_success "pip3 已安装"
        PIP_CMD="pip3"
        return
    fi
    
    # 备用：使用 python3 -m pip
    if python3 -m pip --version &> /dev/null; then
        log_success "pip (python3 -m pip) 可用"
        PIP_CMD="python3 -m pip"
        return
    fi
    
    log_error "pip 未安装"
    show_pip_install_guide
    exit 1
}

# 版本号比较
version_check() {
    local version="$1"
    local min_version="$2"
    
    # 简单比较：提取主版本号
    local major=$(echo "$version" | cut -d'.' -f1)
    local minor=$(echo "$version" | cut -d'.' -f2)
    local min_major=$(echo "$min_version" | cut -d'.' -f1)
    local min_minor=$(echo "$min_version" | cut -d'.' -f2)
    
    if [ "$major" -gt "$min_major" ] || 
       ([ "$major" -eq "$min_major" ] && [ "$minor" -ge "$min_minor" ]); then
        return 0
    else
        return 1
    fi
}

# 显示 Python 安装指南
show_python_install_guide() {
    echo ""
    echo "请安装 Python 3.8+:"
    echo ""
    echo "  Ubuntu/Debian:"
    echo "    sudo apt update"
    echo "    sudo apt install python3 python3-venv python3-pip"
    echo ""
    echo "  macOS (Homebrew):"
    echo "    brew install python3"
    echo ""
    echo "  CentOS/RHEL:"
    echo "    sudo yum install python3 python3-venv python3-pip"
    echo ""
    echo "  其他系统：https://www.python.org/downloads/"
}

# 显示 pip 安装指南
show_pip_install_guide() {
    echo ""
    echo "请安装 pip:"
    echo ""
    echo "  Ubuntu/Debian:"
    echo "    sudo apt install python3-pip"
    echo ""
    echo "  macOS (Homebrew):"
    echo "    brew install python3"
    echo ""
    echo "  或使用 get-pip.py:"
    echo "    curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py"
    echo "    python3 get-pip.py --user"
}

# 创建虚拟环境
create_venv() {
    log_info "创建虚拟环境..."
    
    VENV_DIR="$INSTALL_DIR/venv"
    
    if [ -d "$VENV_DIR" ]; then
        log_info "虚拟环境已存在，跳过创建"
        return
    fi
    
    python3 -m venv "$VENV_DIR"
    
    if [ $? -ne 0 ]; then
        log_error "创建虚拟环境失败"
        exit 1
    fi
    
    log_success "虚拟环境已创建：$VENV_DIR"
}

# 创建安装目录（用户目录，无需 sudo）
create_directories() {
    log_info "创建安装目录..."
    
    mkdir -p "$INSTALL_DIR"
    mkdir -p "$CONFIG_DIR"
    mkdir -p "$LOG_DIR"
    mkdir -p "$BIN_DIR"
    
    log_success "安装目录：$INSTALL_DIR"
    log_success "配置目录：$CONFIG_DIR"
    log_success "日志目录：$LOG_DIR"
    log_success "CLI 目录：$BIN_DIR"
}

# 下载代码
download_code() {
    log_info "下载 Bridge Server 代码..."
    
    # 方式 1: 从 GitHub 下载
    if command -v git &> /dev/null; then
        git clone https://github.com/your-org/bridge-server.git "$INSTALL_DIR/src" || {
            log_warning "Git 克隆失败，尝试下载 ZIP..."
            download_zip
        }
    else
        # 方式 2: 直接下载 ZIP
        download_zip
    fi
    
    log_success "代码下载完成"
}

download_zip() {
    curl -L https://github.com/your-org/bridge-server/archive/main.zip -o /tmp/bridge-server.zip
    unzip /tmp/bridge-server.zip -d "$INSTALL_DIR"
    
    # 处理不同的目录名（bridge-server-main 或 bridge-server-product）
    if [ -d "$INSTALL_DIR/bridge-server-main" ]; then
        mv "$INSTALL_DIR/bridge-server-main"/* "$INSTALL_DIR/src/"
        rm -rf "$INSTALL_DIR/bridge-server-main"
    elif [ -d "$INSTALL_DIR/bridge-server-product" ]; then
        mv "$INSTALL_DIR/bridge-server-product"/* "$INSTALL_DIR/src/"
        rm -rf "$INSTALL_DIR/bridge-server-product"
    else
        log_error "无法找到源代码目录"
        exit 1
    fi
    
    rm -f /tmp/bridge-server.zip
}

# 安装依赖（使用虚拟环境，无需 sudo）
install_dependencies() {
    log_info "安装 Python 依赖..."
    cd "$INSTALL_DIR/src"
    
    # 激活虚拟环境
    if [ -d "$VENV_DIR" ]; then
        source "$VENV_DIR/bin/activate"
        log_info "已激活虚拟环境"
    else
        log_warning "虚拟环境不存在，使用系统 pip"
    fi
    
    # 升级 pip
    $PIP_CMD install --upgrade pip
    
    # 安装依赖（优先使用 wheel，避免编译）
    if $PIP_CMD install --only-binary :all: -r requirements.txt 2>/dev/null; then
        log_success "依赖安装完成（使用预编译 wheel）"
    else
        # 如果 wheel 安装失败，尝试正常安装（可能需要编译工具）
        log_warning "部分包需要编译，尝试正常安装..."
        $PIP_CMD install -r requirements.txt
        log_success "依赖安装完成"
    fi
    
    # 记录使用的 Python 和 pip 路径
    log_info "Python 路径：$(which python3)"
    log_info "pip 路径：$(which pip)"
}

# 创建配置文件
create_config() {
    log_info "创建配置文件..."
    
    if [ ! -f "$CONFIG_DIR/config.yaml" ]; then
        cp "$INSTALL_DIR/src/config.yaml.example" "$CONFIG_DIR/config.yaml"
        
        # 生成随机认证 token
        RANDOM_TOKEN="bridge-$(openssl rand -hex 16 2>/dev/null || head -c 32 /dev/urandom | md5sum | cut -d' ' -f1)"
        
        # 替换配置文件中的占位符
        sed -i.bak "s/REPLACE_WITH_RANDOM_TOKEN/$RANDOM_TOKEN/g" "$CONFIG_DIR/config.yaml" 2>/dev/null || \
        sed -i '' "s/REPLACE_WITH_RANDOM_TOKEN/$RANDOM_TOKEN/g" "$CONFIG_DIR/config.yaml" 2>/dev/null || \
        log_warning "无法自动替换 token，请手动修改配置文件"
        
        rm -f "$CONFIG_DIR/config.yaml.bak"
        
        log_success "配置文件已创建：$CONFIG_DIR/config.yaml"
        log_success "认证 Token 已自动生成：$RANDOM_TOKEN"
        log_info "请将此 token 保存在安全的地方，或修改配置文件自定义"
    else
        log_info "配置文件已存在，跳过"
    fi
}

# 创建 .env 文件（环境变量配置）
create_env_file() {
    log_info "创建环境变量配置..."
    
    if [ ! -f "$CONFIG_DIR/.env" ]; then
        cat > "$CONFIG_DIR/.env" << 'EOF'
# Bridge Server 环境变量配置
# ⚠️  请替换为你的真实 API Key

# 阿里云百炼（推荐，性价比高）
# 获取地址：https://dashscope.console.aliyun.com/apiKey
DASHSCOPE_API_KEY=sk-your-dashscope-api-key-here

# Moonshot (Kimi) - 可选
# 获取地址：https://platform.moonshot.cn/console/api-keys
# MOONSHOT_API_KEY=sk-your-moonshot-key-here

# OpenAI - 可选
# OPENAI_API_KEY=sk-your-openai-key-here

# MiniMax - 可选
# MINIMAX_API_KEY=your-minimax-key-here
EOF
        
        log_success ".env 文件已创建：$CONFIG_DIR/.env"
        log_warning "请编辑 .env 文件，填入你的真实 API Key"
        log_info "编辑命令：vi $CONFIG_DIR/.env"
    else
        log_info ".env 文件已存在，跳过"
    fi
}

# 创建系统服务（根据平台选择）
create_system_service() {
    log_info "配置系统服务..."
    
    case "$ENVIRONMENT" in
        linux-systemd)
            create_systemd_service
            ;;
        macos-launchd)
            create_launchd_service
            ;;
        docker)
            log_info "Docker 环境，跳过系统服务配置"
            ;;
        standalone)
            log_warning "不支持系统服务，将使用后台进程方式"
            ;;
    esac
}

# 创建 systemd 服务（Linux）
create_systemd_service() {
    log_info "创建 systemd 服务..."
    
    # 用户级 systemd 服务（无需 sudo）
    SYSTEMD_USER_DIR="$HOME/.config/systemd/user"
    mkdir -p "$SYSTEMD_USER_DIR"
    
    cat > "$SYSTEMD_USER_DIR/bridge-server.service" <<EOF
[Unit]
Description=Bridge Server - LLM Model Router
After=network.target

[Service]
Type=simple
WorkingDirectory=$INSTALL_DIR/src
ExecStart=$(which python3) -m uvicorn app.main:app --host 0.0.0.0 --port 8080 --workers 1
Restart=always
RestartSec=5
Environment=PATH=$BIN_DIR:$PATH

[Install]
WantedBy=default.target
EOF

    # 启用服务（用户级，无需 sudo）
    systemctl --user daemon-reload
    systemctl --user enable bridge-server.service
    
    log_success "systemd 用户服务已创建"
    log_info "启动服务：systemctl --user start bridge-server"
    log_info "查看状态：systemctl --user status bridge-server"
}

# 创建 launchd 服务（macOS）
create_launchd_service() {
    log_info "创建 launchd 服务..."
    
    LAUNCHD_DIR="$HOME/Library/LaunchAgents"
    mkdir -p "$LAUNCHD_DIR"
    
    cat > "$LAUNCHD_DIR/com.bridge-server.app.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.bridge-server.app</string>
    <key>ProgramArguments</key>
    <array>
        <string>$(which python3)</string>
        <string>-m</string>
        <string>uvicorn</string>
        <string>app.main:app</string>
        <string>--host</string>
        <string>0.0.0.0</string>
        <string>--port</string>
        <string>8080</string>
        <string>--workers</string>
        <string>1</string>
    </array>
    <key>WorkingDirectory</key>
    <string>$INSTALL_DIR/src</string>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <true/>
    <key>StandardOutPath</key>
    <string>$LOG_DIR/bridge-server.log</string>
    <key>StandardErrorPath</key>
    <string>$LOG_DIR/bridge-server.err.log</string>
</dict>
</plist>
EOF

    # 加载服务（无需 sudo）
    launchctl load "$LAUNCHD_DIR/com.bridge-server.app.plist"
    
    log_success "launchd 服务已创建"
    log_info "启动服务：launchctl start com.bridge-server.app"
    log_info "停止服务：launchctl stop com.bridge-server.app"
}

# 创建命令行工具（用户目录，无需 sudo）
create_cli() {
    log_info "创建命令行工具..."
    
    # 创建 CLI 启动脚本（自动激活虚拟环境）
    cat > "$BIN_DIR/bridge-server" <<'EOF'
#!/bin/bash
# Bridge Server CLI（用户级安装 - 自动激活虚拟环境）

INSTALL_DIR="${INSTALL_DIR:-$HOME/.local/opt/bridge-server}"
CONFIG_DIR="${CONFIG_DIR:-$HOME/.bridge-server}"
SRC_DIR="$INSTALL_DIR/src"
VENV_DIR="$INSTALL_DIR/venv"

# 检测运行环境
detect_env() {
    if command -v systemctl &> /dev/null && [ -d /etc/systemd/system ]; then
        echo "linux-systemd"
    elif command -v launchctl &> /dev/null; then
        echo "macos-launchd"
    else
        echo "standalone"
    fi
}

ENV=$(detect_env)

case "$1" in
    start)
        echo "启动 Bridge Server..."
        
        # 激活虚拟环境（如果存在）
        if [ -d "$VENV_DIR" ]; then
            source "$VENV_DIR/bin/activate"
        fi
        
        case "$ENV" in
            linux-systemd)
                systemctl --user start bridge-server
                ;;
            macos-launchd)
                launchctl start com.bridge-server.app
                ;;
            *)
                cd "$SRC_DIR"
                nohup python3 -m uvicorn app.main:app --host 0.0.0.0 --port 8080 >> "$HOME/.bridge-server/logs/bridge-server.log" 2>&1 &
                echo $! > "$CONFIG_DIR/bridge-server.pid"
                ;;
        esac
        echo "✅ 服务已启动"
        ;;
    stop)
        echo "停止 Bridge Server..."
        case "$ENV" in
            linux-systemd)
                systemctl --user stop bridge-server
                ;;
            macos-launchd)
                launchctl stop com.bridge-server.app
                ;;
            *)
                if [ -f "$CONFIG_DIR/bridge-server.pid" ]; then
                    kill $(cat "$CONFIG_DIR/bridge-server.pid") 2>/dev/null || true
                    rm -f "$CONFIG_DIR/bridge-server.pid"
                else
                    pkill -f 'uvicorn app.main:app' || true
                fi
                ;;
        esac
        echo "✅ 服务已停止"
        ;;
    restart)
        $0 stop
        sleep 2
        $0 start
        ;;
    status)
        case "$ENV" in
            linux-systemd)
                systemctl --user status bridge-server
                ;;
            macos-launchd)
                launchctl list | grep bridge-server || echo "服务未运行"
                ;;
            *)
                if pgrep -f 'uvicorn app.main:app' > /dev/null; then
                    echo "✅ 服务运行中"
                else
                    echo "❌ 服务未运行"
                fi
                ;;
        esac
        ;;
    logs)
        LOG_FILE="$HOME/.bridge-server/logs/bridge-server.log"
        if [ -f "$LOG_FILE" ]; then
            tail -f "$LOG_FILE"
        else
            echo "日志文件不存在"
        fi
        ;;
    test)
        echo "测试连接..."
        curl -X POST http://localhost:8080/health
        echo ""
        ;;
    setup)
        python3 "$SRC_DIR/setup-wizard.py"
        ;;
    *)
        echo "Bridge Server CLI"
        echo ""
        echo "用法：bridge-server <command>"
        echo ""
        echo "命令:"
        echo "  start      启动服务"
        echo "  stop       停止服务"
        echo "  restart    重启服务"
        echo "  status     查看状态"
        echo "  logs       查看日志"
        echo "  test       测试连接"
        echo "  setup      运行配置向导"
        echo ""
        ;;
esac
EOF

    chmod +x "$BIN_DIR/bridge-server"
    
    log_success "命令行工具已安装：$BIN_DIR/bridge-server"
    log_info ""
    log_info "请将 $BIN_DIR 添加到 PATH:"
    log_info "  export PATH=\"$BIN_DIR:\$PATH\""
    log_info ""
    log_info "建议添加到 ~/.bashrc 或 ~/.zshrc:"
    log_info "  echo 'export PATH=\"$BIN_DIR:\$PATH\"' >> ~/.bashrc"
}

# 运行配置向导
run_wizard() {
    echo ""
    log_info "运行配置向导..."
    echo ""
    python3 "$INSTALL_DIR/src/setup-wizard.py"
}

# 显示完成信息
show_completion_message() {
    echo ""
    log_success "安装完成！"
    echo ""
    echo "接下来："
    echo "  1. 添加 CLI 到 PATH:"
    echo "     export PATH=\"$BIN_DIR:\$PATH\""
    echo ""
    echo "  2. 运行配置向导：bridge-server setup"
    echo ""
    echo "  3. 启动服务：bridge-server start"
    echo ""
    echo "  4. 测试连接：bridge-server test"
    echo ""
    
    # 询问是否运行配置向导
    read -p "现在运行配置向导？[Y/n] " -n 1 -r
    echo ""
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        run_wizard
    fi
}

# 主函数
main() {
    echo ""
    echo "╔═══════════════════════════════════════════╗"
    echo "║     Bridge Server 安装程序                ║"
    echo "║          LLM Model Router & Gateway       ║"
    echo "║          (跨平台 - 无需 root 权限)          ║"
    echo "╚═══════════════════════════════════════════╝"
    echo ""
    
    # 检测是否从本地源码安装
    if [ -f "requirements.txt" ] && [ -d "app" ]; then
        log_info "检测到本地源代码，使用本地安装模式"
        INSTALL_MODE="local"
    else
        log_info "使用在线安装模式（从 GitHub 下载）"
        INSTALL_MODE="online"
    fi
    
    detect_environment
    check_python_venv
    check_pip
    create_directories
    
    # 根据安装模式选择代码来源
    if [ "$INSTALL_MODE" = "local" ]; then
        install_from_local
    else
        download_code
    fi
    
    create_venv
    install_dependencies
    create_config
    create_env_file
    create_system_service
    create_cli
    
    show_completion_message
}

# 从本地源码安装
install_from_local() {
    log_info "从本地源代码安装..."
    
    # 获取当前脚本所在目录
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    
    # 复制源代码到安装目录
    mkdir -p "$INSTALL_DIR/src"
    cp -r "$SCRIPT_DIR"/* "$INSTALL_DIR/src/"
    
    log_success "本地源代码已复制到：$INSTALL_DIR/src"
}

# 运行主函数
main
