# 🎉 Bridge Server v1.0.0 正式发布

**发布日期**: 2026-04-06  
**版本**: 1.0.0 Community Edition  
**类型**: 正式版本（稳定版）

---

## 🌟 产品介绍

**Bridge Server** 是一个智能 LLM 模型路由网关，帮助您：

- 💰 **节省 60%+ AI 成本** - 智能路由，简单任务用便宜模型
- 🎯 **统一接口** - 一次接入，支持所有主流 AI 平台
- 📊 **用量透明** - 实时统计，预算告警，每一分钱都花得明白
- 🔐 **企业级安全** - JWT 认证、速率限制、审计日志
- 🚀 **跨平台部署** - Linux/macOS/Windows 一键安装

---

## ✨ 核心功能

### 🧠 智能模型路由

根据任务类型自动选择最优模型：

```python
# 你只需调用一次
POST /v1/chat/completions
{
  "messages": [{"role": "user", "content": "用 Python 写个快速排序"}]
}

# Bridge Server 自动选择 coding 专用模型
# 如果是问候，自动选择最便宜的模型
# 如果是复杂推理，自动选择最强模型
```

**三种路由策略**:
- 🟢 **平衡模式** - 性价比最优（推荐）
- 🔵 **成本优先** - 能省则省
- 🟣 **质量优先** - 全部最强模型

---

### 💰 成本透明可控

**实时用量统计**:
```bash
$ bridge-server usage --today

今日用量报告
━━━━━━━━━━━━━━━━━━━━━━━
总请求数：1,234
总花费：¥12.34
平均每次：¥0.01
```

**预算告警**:
- 50% 使用量 → 邮件提醒
- 80% 使用量 → 邮件 + 短信
- 90% 使用量 → 全渠道告警
- 100% 使用量 → 自动降级或暂停

---

### 🔐 企业级安全

- ✅ JWT Token 认证
- ✅ API Key 管理
- ✅ 速率限制（防滥用）
- ✅ JS 沙箱（安全执行自定义路由逻辑）
- ✅ 审计日志（所有操作可追溯）

---

### 🚀 跨平台一键部署

**Linux/macOS**:
```bash
curl -fsSL https://example.com/install.sh | bash
```

**Windows PowerShell**:
```powershell
Invoke-WebRequest -Uri https://example.com/install.ps1 -OutFile install.ps1
.\install.ps1
```

**Docker**:
```bash
docker run -d -p 19377:19377 \
  -v ~/.bridge-server:/root/.bridge-server \
  bridgedev/bridge-server:latest
```

---

## 📊 支持的 AI 平台

| 平台 | 模型 | 成本优势 | 状态 |
|------|------|---------|------|
| **阿里云百炼** | Qwen 系列 | 💰💰💰💰💰 | ✅ 已支持 |
| **Moonshot** | Kimi | 💰💰💰💰 | ✅ 已支持 |
| **OpenAI** | GPT 系列 | 💰💰💰 | ✅ 已支持 |
| **MiniMax** | M2.5 | 💰💰💰💰 | ✅ 已支持 |

---

## 🔧 技术规格

### 系统要求

| 系统 | 版本 | Python |
|------|------|--------|
| Linux | Ubuntu 18.04+ / CentOS 7+ | 3.8+ |
| macOS | 10.14+ | 3.8+ |
| Windows | 10+ | 3.8+ |
| Docker | Any | 包含 |

### 技术栈

- **后端**: FastAPI (Python 3.8+)
- **数据库**: SQLite (默认) / MySQL (可选)
- **缓存**: Redis (可选)
- **部署**: Docker / Systemd / Standalone

---

## 📦 安装方式

### 方式 1: 一键安装（推荐）

**Linux/macOS**:
```bash
curl -fsSL https://example.com/install.sh | bash
```

**Windows**:
```powershell
Invoke-WebRequest -Uri https://example.com/install.ps1 -OutFile install.ps1
.\install.ps1
```

### 方式 2: Docker

```bash
docker run -d -p 19377:19377 \
  -v ~/.bridge-server:/root/.bridge-server \
  bridgedev/bridge-server:latest
```

### 方式 3: 源码安装

```bash
git clone https://github.com/your-org/bridge-server.git
cd bridge-server
pip3 install -r requirements.txt
bridge-server setup
```

---

## 🎓 快速开始

### 步骤 1: 安装

```bash
curl -fsSL https://example.com/install.sh | bash
```

### 步骤 2: 配置

```bash
# 编辑配置文件
vi ~/.bridge-server/.env

# 填入你的 API Key
DASHSCOPE_API_KEY=sk-xxx
MOONSHOT_API_KEY=sk-xxx
```

### 步骤 3: 启动

```bash
bridge-server start
```

### 步骤 4: 测试

```bash
curl -X POST http://localhost:19377/v1/chat/completions \
  -H "Authorization: Bearer your-token" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "你好"}]}'
```

**完成！🎉**

---

## 📝 变更日志

### v1.0.0 (2026-04-06)

**新功能**:
- ✅ RESTful API 网关（11 个标准化端点）
- ✅ JWT Token 认证系统
- ✅ 智能模型路由（3 种策略）
- ✅ 用量统计和预算告警
- ✅ JS 沙箱（安全执行自定义路由代码）
- ✅ CLI 工具增强（6 个新命令）
- ✅ 跨平台一键安装（Linux/macOS/Windows）

**改进**:
- ✅ 数据库支持（SQLite/MySQL）
- ✅ 高并发写入优化
- ✅ 错误处理优化
- ✅ 日志格式改进

**安全**:
- ✅ 速率限制
- ✅ API Key 管理
- ✅ 审计日志
- ✅ JS 沙箱隔离

**文档**:
- ✅ 完整的 README.md
- ✅ 快速开始指南
- ✅ API 参考文档
- ✅ 故障排查指南

---

## 🧪 测试报告

### 单元测试

```
======================== 测试总览 ========================
总测试收集：141
实际运行：138
通过：138 (100%) ✅
失败：0 (0%)
跳过：3 (2.1% - MySQL/Redis 相关)
执行时间：5.55s
========================================================
```

### 核心模块通过率

| 模块 | 通过率 |
|------|--------|
| RESTful API | 100% ✅ |
| JWT 认证 | 100% ✅ |
| 智能路由 | 100% ✅ |
| JS 沙箱 | 100% ✅ |
| 用量统计 | 100% ✅ |
| 数据库 | 100% ✅ |

---

## 📚 文档

- [🚀 快速开始](docs/QUICKSTART.md)
- [⚙️ 配置指南](docs/CONFIG.md)
- [📖 API 参考](docs/API.md)
- [🧠 路由策略](docs/ROUTING.md)
- [🔧 故障排查](docs/TROUBLESHOOTING.md)

---

## 🤝 贡献

欢迎贡献代码、文档或建议！

详见 [贡献指南](CONTRIBUTING.md)

---

## 📄 许可证

MIT License - 详见 [LICENSE](LICENSE) 文件

---

## 📞 支持

- 🐛 **Bug 反馈**: [GitHub Issues](https://github.com/your-org/bridge-server/issues)
- 💬 **讨论交流**: [Discussions](https://github.com/your-org/bridge-server/discussions)
- 📧 **邮件联系**: support@example.com
- 📖 **文档**: https://docs.bridge-server.dev

---

## 🎉 致谢

感谢所有贡献者和用户！

Made with ❤️ by Bridge Server Team

---

**让 AI 更便宜、更易用！** 🚀
